# rustplusplus Documentation

## Table of Contents

* [**Installation**](installation.md)
* [**Discord Bot Setup**](discord_bot_setup.md)
* [**Credentials**](credentials.md) OR [**Credentials(WebVersion)**](credentials_web_version.md)
* [**Pair & Connect Server**](pair_and_connect_to_server.md)
* [**Commands**](commands.md)
* [**Discord Text Channels**](discord_text_channels.md)
* [**Smart Devices**](smart_devices.md)
